﻿using System;
using CallOfDuty.Enemies;
using CallOfDuty.Weapons;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CallOfDuty.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ShootGruntWithShotgun()
        {
            Weapon testWeapon = new Shotgun();
            Enemy testEnemy = new Grunt();

            testWeapon.Shoot(testEnemy);
            Assert.AreEqual(90, testEnemy.EnergyRemaining);
        }

        [TestMethod]
        public void AddAmmoToShotgun()
        {
            Weapon testWeapon = new Shotgun();

            testWeapon.AddAmmo(20);

            // After you implement AddAmmo and the public property that stores the ammo,
            // fill out the assert accordingly.
             Assert.AreEqual(20, testWeapon.ammoRemaining);
        }
    }
}
