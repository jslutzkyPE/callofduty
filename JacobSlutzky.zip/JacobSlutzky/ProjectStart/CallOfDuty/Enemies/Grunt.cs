﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CallOfDuty.Enemies
{
    public class Grunt : Enemy
    {
        public Grunt()
        {
            EnergyRemaining = 100;
        }
    }
}
