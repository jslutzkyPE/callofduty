﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CallOfDuty.Enemies
{
    public class Sergeant : Enemy
    {
        public Sergeant()
        {
            EnergyRemaining = 200;
        }
    }
}
