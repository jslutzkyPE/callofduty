﻿namespace CallOfDuty.Enemies
{
    public abstract class Enemy
    {
        public boolean alive {get; protected set; }
        public int EnergyRemaining { get; protected set; }
        
        public void ReceiveDamage(int damage)
        {
            EnergyRemaining -= damage;
            if(EnergyRemaining <= 0){
                alive = false;
            }
            else{
                alive = true;
            }
            
        }
    }
}
