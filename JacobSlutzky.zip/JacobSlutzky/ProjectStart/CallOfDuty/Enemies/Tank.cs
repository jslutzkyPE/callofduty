using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CallOfDuty.Enemies
{
    public class Tank : Enemy
    {
        public Tank()
        {
            EnergyRemaining = 1000;
        }
        public void ReceiveDamage(int damage){
            if(damage >= 500){
            EnergyRemaining -= damage;
            if(EnergyRemaining <= 0){
                alive = false;
            }
            else{
                alive = true;
            }
        }

        }
    }
}