﻿namespace CallOfDuty.Weapons
{
    public class Shotgun : Weapon
    {
        public Shotgun()
        {
            DamagePoints = 10;
            maxAmmo = 50;
        }
    }
}
