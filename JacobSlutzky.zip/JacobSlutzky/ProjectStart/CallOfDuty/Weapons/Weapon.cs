﻿using System;
using CallOfDuty.Enemies;

namespace CallOfDuty.Weapons
{
    public abstract class Weapon
    {
        protected int DamagePoints;
        public int ammoRemaining;

        protected int maxAmmo;
        public void AddAmmo(int amount)
        {
            if (ammoRemaining + amount >= maxAmmo){
                ammoRemaining = maxAmmo;
            }
            else{}
            ammoRemaining += amount;
        }
        }

        public void Shoot(Enemy enemy)
        {
            if(ammoRemaining != 0){
                enemy.ReceiveDamage(DamagePoints);
                ammoRemaining -= 1;
            }
        }
    }

