namespace CallOfDuty.Weapons
{

public class Bazooka : Weapon
{
    public Bazooka(){
        DamagePoints = 500;
        maxAmmo = 2;
    }
}
}