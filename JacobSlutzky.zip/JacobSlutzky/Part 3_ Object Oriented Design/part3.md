# Part 3: Object Oriented Design

Reading: 



For this part, we're going to add a fundamentally new kind of weapon--an **Assault Rifle**.  

This part is an opportunity for you to apply your problem-solving and programming skills to **lay out a** *design* and **identify** *tricky areas* that might need input from more experienced developers--and it's a great way to identify new skills that you'd like to develop professionally.

Since the Assault Rifle is a bit more involved, we'll start by doing some up front design.  You can write pseudo-code, or draw diagrams, or whatever you'd like to turn the requirements into something that can be implemented by a developer.  

The main focus of this exercise is meant to open up the discussion about how design patterns help developers build elegant and flexible code--as well as some really, really fun games!

## Assault Rifle Requirements

Max ammo: 500
Damage: 100
Accuracy: .25 (This is a new field unique to the Assault Rifle) -- we will multiply it against the damage value
Fire modes
Single shot: Use 1 unit of ammunition per call to Shoot().
Three-shot burst: Use 3 unit of ammunition per call to Shoot().
Full auto: Use 10 rounds of ammunition per call to Shoot().

The Assault Rifle has options for three types of attachments. 

## Attachments 

Can all be added to the gun at the same time (see screenshot for an example).

### Barrel attachment
A barrel attachment, if present, will modify the amount of damage that the weapon does.

### Auxiliary fire attachment (the screenshot below calls this an under-barrel attachment)
A auxiliary fire attachment, if present, is basically a second type of weapon with its own max ammo and damage. It should not inherit from the Weapon class though, because it can't be used except when mounted to an Assault Rifle.

### Sight
A barrel attachment, if present, will modify the accuracy of the weapon.
Questions to ponder:

The Assault Rifle class has a bunch of new concepts, like attachments and this new "accuracy" value. 

At the end of the day, it's also still a Weapon. 

We're starting to see a wide range of weapons--ranging from:
*  a knife (which has no features)
*  to a Pulse Rifle (which behaves in a special way when it shoots) 
*  to this Assault Rifle, which seems crazy complicated! 
  
What should (or shouldn't) change on the base Weapon class?

If we want to add more weapons that have the capacity for attachments, how should we structure our interfaces or base classes?

How can we write our code so the Assault Rifle behaves properly when the attachments are present, or missing?

How should we design the Assault Rifle class so we can have an "inventory" of attachments, and toggle between them, like what we see in the screenshot below?